#!/bin/bash
# for each in $(ls)
# do
#     echo "your file is: ${each}"
#     # if command -v ${each} 1>/dev/null 2>&1 ; then 
#     #     echo "${each} is already deployed"
#     # else 
#     #     echo "${each} is not installed"
#     # fi
# done


for (( ; ; ))
do 
  echo "this is one more for loop syntax"
done 