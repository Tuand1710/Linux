java -version
docker --version
ansible --version
