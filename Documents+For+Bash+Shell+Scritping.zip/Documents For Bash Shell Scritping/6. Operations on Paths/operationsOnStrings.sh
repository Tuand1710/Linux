#!/usr/bin/bash
myShell=bash
#myShellLen=${#myShell}
#echo "The len of a string ${myShell} is: ${myShellLen}"
#myScr="shell scripting"
#myShellScr="${myShell} ${myScr}"
#echo "${myShellScr}"

#myShellUpp=${myShell^^}
#echo "${myShellUpp}"

#myNewShell=BASH
#myShellLow=${myNewShell,,}
#echo "${myShellLow}"



myShellScr="Bash Shell Scripting"
echo "${myShellScr::}"



