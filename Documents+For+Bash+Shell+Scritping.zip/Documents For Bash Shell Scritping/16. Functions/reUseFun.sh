#!/bin/bash
source /home/VRTech/automation/onlyFuns.sh 

validateTool nginx