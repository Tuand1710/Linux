
#!/usr/bin/bash
declare -a myValues
myValues=(1 2 3 4 56 7)



