#!/usr/bin/bash
echo "${0}"
echo "${1}"
shift 1
echo "${2}"

echo "${0}"

