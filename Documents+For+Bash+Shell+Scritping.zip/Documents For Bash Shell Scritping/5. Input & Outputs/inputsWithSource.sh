#!/usr/bin/bash
source /home/VRTech/automation/commonVars

echo "${containerTool}"
echo "${cmTool}"
