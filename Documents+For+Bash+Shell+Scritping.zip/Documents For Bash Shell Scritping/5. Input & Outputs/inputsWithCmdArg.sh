#!/usr/bin/bash
echo "${1}"
echo "${5}"
echo "${9}"
echo "${10}"
echo "${11}"

echo "${#}"
echo "${*}"
echo "${@}"

echo "${0}"

myValue=${5}
